<?php

/**
 * Plugin Name: Space Usage Alpha
 * Description: Monitor your disk space, memory usage, database size, and WP content folder size.
 * Version: 1.0.0
 * Author: Zain Minhas
 * Text Domain: space-usage-alpha
 * Domain Path: /languages
 * License: GPL-2.0+
 * Plugin URI: assets/images/space-usage.jpg
 */

namespace SpaceUsageAlpha;

// Exit if accessed directly.
defined('ABSPATH') || exit;

// Define plugin constants
define('SUA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('SUA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SUA_VERSION', '1.0.0');
define('SUA_MIN_WP_VERSION', '5.0');
define('SUA_MIN_PHP_VERSION', '7.0');

// Include necessary files
require_once __DIR__ . '/includes/Admin/AdminPage.php';
require_once __DIR__ . '/includes/Admin/Enqueue.php';
require_once __DIR__ . '/includes/Ajax/AjaxHandler.php';
require_once __DIR__ . '/includes/Settings/Settings.php';

/**
 * Initialize the plugin
 */
function init() {
    // Check WP and PHP versions
    if (version_compare(get_bloginfo('version'), SUA_MIN_WP_VERSION, '<') ||
        version_compare(PHP_VERSION, SUA_MIN_PHP_VERSION, '<')) {
        add_action('admin_notices', __NAMESPACE__ . '\\version_error');
        return;
    }

    // Load textdomain
    load_plugin_textdomain('space-usage-alpha', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // Initialize plugin components
    Admin\AdminPage::register();
    Admin\Enqueue::register();
    Ajax\AjaxHandler::register();
}

/**
 * Display version error message
 */
function version_error() {
    $message = sprintf(
        __('Space Usage Alpha requires WordPress version %s and PHP version %s or higher.', 'space-usage-alpha'),
        SUA_MIN_WP_VERSION,
        SUA_MIN_PHP_VERSION
    );
    echo '<div class="error"><p>' . esc_html($message) . '</p></div>';
}

/**
 * Add settings link to plugins page
 */
function add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=space-usage-alpha') . '">' . __('Settings', 'space-usage-alpha') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// Hook initialization function
add_action('plugins_loaded', __NAMESPACE__ . '\\init');

// Register activation and deactivation hooks
register_activation_hook(__FILE__, __NAMESPACE__ . '\\Admin\\AdminPage::activate');
register_deactivation_hook(__FILE__, __NAMESPACE__ . '\\Admin\\AdminPage::deactivate');

// Add settings link filter
add_filter('plugin_action_links_' . plugin_basename(__FILE__), __NAMESPACE__ . '\\add_settings_link');

/**
 * Autoloader function
 */
function autoloader($class) {
    // Project-specific namespace prefix
    $prefix = 'SpaceUsageAlpha\\';

    // Base directory for the namespace prefix
    $base_dir = __DIR__ . '/includes/';

    // Does the class use the namespace prefix?
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        // No, move to the next registered autoloader
        return;
    }

    // Get the relative class name
    $relative_class = substr($class, $len);

    // Replace the namespace prefix with the base directory, replace namespace
    // separators with directory separators in the relative class name, append
    // with .php
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // If the file exists, require it
    if (file_exists($file)) {
        require $file;
    }
}

// Register the autoloader
spl_autoload_register(__NAMESPACE__ . '\\autoloader');

/**
 * Enqueue admin scripts and styles
 */
function enqueue_scripts() {
    wp_enqueue_script('jquery'); // Ensure jQuery is loaded
    wp_enqueue_script('space-usage-alpha-script', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], null, true);
}

// Hook to enqueue admin scripts
add_action('admin_enqueue_scripts', __NAMESPACE__ . '\\enqueue_scripts');
