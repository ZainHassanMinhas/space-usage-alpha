<?php
// Exit if accessed directly.
defined('ABSPATH') || exit;

// Cleanup code (e.g., delete options from the database)
