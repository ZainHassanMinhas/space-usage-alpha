<?php

namespace SpaceUsageAlpha\Ajax;

// Exit if accessed directly.
defined('ABSPATH') || exit;

class AjaxHandler {

    const CACHE_EXPIRATION = 300; // 5 minutes

    public static function register() {
        add_action('wp_ajax_sua_get_disk_space_memory_usage', [__CLASS__, 'get_disk_space_memory_usage']);
        add_action('wp_ajax_sua_get_database_size', [__CLASS__, 'get_database_size']);
        add_action('wp_ajax_sua_get_wp_content_size', [__CLASS__, 'get_wp_content_size']);
        add_action('wp_ajax_sua_get_media_size', [__CLASS__, 'get_media_size']);
    }

    public static function get_disk_space_memory_usage() {
        self::verify_request();

        $cache_key = 'sua_disk_memory_usage';
        $result = get_transient($cache_key);

        if (false === $result) {
            try {
                $disk_total = disk_total_space('/');
                $disk_free = disk_free_space('/');
                $disk_used = $disk_total - $disk_free;
                $memory_total = memory_get_usage(true);
                $memory_used = memory_get_usage();

                $result = [
                    'disk_total' => size_format($disk_total),
                    'disk_used' => size_format($disk_used),
                    'memory_total' => size_format($memory_total),
                    'memory_used' => size_format($memory_used),
                ];

                set_transient($cache_key, $result, self::CACHE_EXPIRATION);
            } catch (\Exception $e) {
                wp_send_json_error('Error fetching disk and memory usage: ' . $e->getMessage());
                return;
            }
        }

        wp_send_json_success($result);
    }

    public static function get_database_size() {
        self::verify_request();

        $cache_key = 'sua_database_size';
        $result = get_transient($cache_key);

        if (false === $result) {
            try {
                global $wpdb;

                $tables = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);
                $total_size = 0;
                $tables_list = [];

                foreach ($tables as $table) {
                    $size = $table['Data_length'] + $table['Index_length'];
                    $total_size += $size;
                    $tables_list[] = [
                        'name' => $table['Name'],
                        'size' => size_format($size)
                    ];
                }

                $result = [
                    'total_size' => size_format($total_size),
                    'tables' => $tables_list
                ];

                set_transient($cache_key, $result, self::CACHE_EXPIRATION);
            } catch (\Exception $e) {
                wp_send_json_error('Error fetching database size: ' . $e->getMessage());
                return;
            }
        }

        wp_send_json_success($result);
    }

    public static function get_wp_content_size() {
        self::verify_request();
        $cache_key = 'sua_wp_content_size';
        $result = get_transient($cache_key);
    
        if (false === $result) {
            try {
                $wp_content_path = WP_CONTENT_DIR;
    
                $result = [
                    'total_size' => size_format(self::get_directory_size($wp_content_path)),
                    'plugins_size' => size_format(self::get_directory_size($wp_content_path . '/plugins')),
                    'themes_size' => size_format(self::get_directory_size($wp_content_path . '/themes')),
                    'plugins_list' => self::get_plugin_sizes($wp_content_path . '/plugins'),
                    'themes_list' => self::get_theme_sizes($wp_content_path . '/themes')
                ];
    
                set_transient($cache_key, $result, self::CACHE_EXPIRATION);
            } catch (\Exception $e) {
                wp_send_json_error('Error fetching wp-content size: ' . $e->getMessage());
            }
        }
    
        wp_send_json_success($result);
    }
    
    private static function get_plugin_sizes($dir) {
        $plugins_list = [];
        foreach (new \DirectoryIterator($dir) as $item) {
            if ($item->isDir() && !$item->isDot()) {
                $plugins_list[] = [
                    'name' => $item->getFilename(),
                    'size' => size_format(self::get_directory_size($item->getPathname()))
                ];
            }
        }
        return $plugins_list;
    }
    
    private static function get_theme_sizes($dir) {
        $themes_list = [];
        foreach (new \DirectoryIterator($dir) as $item) {
            if ($item->isDir() && !$item->isDot()) {
                $themes_list[] = [
                    'name' => $item->getFilename(),
                    'size' => size_format(self::get_directory_size($item->getPathname()))
                ];
            }
        }
        return $themes_list;
    }

    public static function get_media_size() {
        self::verify_request();

        $cache_key = 'sua_media_size';
        $result = get_transient($cache_key);

        if (false === $result) {
            try {
                $uploads_dir = wp_upload_dir()['basedir'];
                $result = [
                    'media_size' => size_format(self::get_directory_size($uploads_dir)),
                ];

                set_transient($cache_key, $result, self::CACHE_EXPIRATION);
            } catch (\Exception $e) {
                wp_send_json_error('Error fetching media size: ' . $e->getMessage());
                return;
            }
        }

        wp_send_json_success($result);
    }

    private static function get_directory_size($dir) {
        $size = 0;
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $file) {
            $size += $file->getSize();
        }
        return $size;
    }

    private static function get_directory_files_size($dir) {
        $files_list = [];
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $file) {
            if ($file->isFile()) {
                $files_list[] = [
                    'name' => str_replace(WP_CONTENT_DIR . '/', '', $file->getPathname()),
                    'size' => size_format($file->getSize())
                ];
            }
        }
        return $files_list;
    }

    private static function verify_request() {
        check_ajax_referer('sua_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized access');
            return;
        }
    }

}
