<?php

namespace SpaceUsageAlpha\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

class AdminPage {

    /**
     * Slug for the admin page.
     */
    const PAGE_SLUG = 'space-usage-alpha';

    /**
     * Register hooks and actions.
     */
    public static function register() {
        add_action('admin_menu', [__CLASS__, 'add_admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    /**
     * Plugin activation hook callback.
     */
    public static function activate() {
        // Set default options
        $default_options = [
            'enable_disk_space_monitoring' => 1,
            'enable_memory_usage_monitoring' => 1,
            'enable_database_size_monitoring' => 1,
            'enable_wp_content_size_monitoring' => 1,
        ];
        add_option(self::PAGE_SLUG . '_options', $default_options);
    }

    /**
     * Plugin deactivation hook callback.
     */
    public static function deactivate() {
        // Clear any transients or temporary data
        delete_transient(self::PAGE_SLUG . '_disk_space');
        delete_transient(self::PAGE_SLUG . '_memory_usage');
        delete_transient(self::PAGE_SLUG . '_database_size');
        delete_transient(self::PAGE_SLUG . '_wp_content_size');
    }

    /**
     * Add menu item to the WordPress admin menu.
     */
    public static function add_admin_menu() {
        add_menu_page(
            esc_html__('Space Usage Alpha', 'space-usage-alpha'),
            esc_html__('Space Usage Alpha', 'space-usage-alpha'),
            'manage_options',
            self::PAGE_SLUG,
            [__CLASS__, 'display_admin_page'],
            'dashicons-chart-area'
        );
    }

    /**
     * Display the admin page content.
     */
    public static function display_admin_page() {
        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }

        // Check if settings were updated
        if (isset($_GET['settings-updated'])) {
            add_settings_error(self::PAGE_SLUG . '_messages', self::PAGE_SLUG . '_message', __('Settings Saved', 'space-usage-alpha'), 'updated');
        }

        // Show error/update messages
        settings_errors(self::PAGE_SLUG . '_messages');

        // Include the admin page template
        include SUA_PLUGIN_PATH . 'templates/admin-page.php';
    }

    /**
     * Register plugin settings.
     */
    public static function register_settings() {
        register_setting(self::PAGE_SLUG . '_options_group', self::PAGE_SLUG . '_options');

        add_settings_section(
            self::PAGE_SLUG . '_section',
            __('Monitoring Settings', 'space-usage-alpha'),
            [__CLASS__, 'settings_section_callback'],
            self::PAGE_SLUG
        );

        add_settings_field(
            'enable_disk_space_monitoring',
            __('Enable Disk Space Monitoring', 'space-usage-alpha'),
            [__CLASS__, 'checkbox_field_callback'],
            self::PAGE_SLUG,
            self::PAGE_SLUG . '_section',
            [
                'label_for' => 'enable_disk_space_monitoring',
                'class' => 'sua-row',
                'option_name' => self::PAGE_SLUG . '_options'
            ]
        );

        // Additional settings fields can be added here
    }

    /**
     * Settings section callback.
     */
    public static function settings_section_callback($args) {
        ?>
        <p id="<?php echo esc_attr($args['id']); ?>"><?php esc_html_e('Choose which elements to monitor:', 'space-usage-alpha'); ?></p>
        <?php
    }

    /**
     * Checkbox field callback.
     */
    public static function checkbox_field_callback($args) {
        $options = get_option($args['option_name']);
        ?>
        <input type="checkbox"
               id="<?php echo esc_attr($args['label_for']); ?>"
               name="<?php echo esc_attr($args['option_name']); ?>[<?php echo esc_attr($args['label_for']); ?>]"
               value="1"
               <?php checked(isset($options[$args['label_for']]) ? $options[$args['label_for']] : 0, 1); ?>
        />
        <label for="<?php echo esc_attr($args['label_for']); ?>"><?php esc_html_e('Enable', 'space-usage-alpha'); ?></label>
        <?php
    }
}
