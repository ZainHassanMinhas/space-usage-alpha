<?php

namespace SpaceUsageAlpha\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

class Enqueue {

    /**
     * Version of the plugin assets.
     */
    const ASSET_VERSION = '1.0.0';

    /**
     * Register hooks and actions.
     */
    public static function register() {
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    /**
     * Enqueue admin styles and scripts.
     *
     * @param string $hook The current admin page.
     */
    public static function enqueue_assets($hook) {
        // Only enqueue scripts/styles on the specific admin page.
        if ($hook !== 'toplevel_page_space-usage-alpha') {
            return;
        }

        self::enqueue_styles();
        self::enqueue_scripts();
    }

    /**
     * Enqueue styles.
     */
    private static function enqueue_styles() {
        wp_enqueue_style(
            'sua-styles',
            SUA_PLUGIN_URL . 'assets/css/styles.css',
            [],
            self::get_file_version('assets/css/styles.css')
        );
    }

    /**
     * Enqueue scripts.
     */
    private static function enqueue_scripts() {
        wp_enqueue_script(
            'sua-scripts',
            SUA_PLUGIN_URL . 'assets/js/scripts.js',
            ['jquery'],
            self::get_file_version('assets/js/scripts.js'),
            true
        );

        // Localize script for AJAX functionality.
        wp_localize_script('sua-scripts', 'sua_ajax_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sua_nonce'),
            'i18n' => [
                'error' => __('An error occurred. Please try again.', 'space-usage-alpha'),
                'success' => __('Operation completed successfully.', 'space-usage-alpha'),
                'show_details' => __('Show Details', 'space-usage-alpha'),
                'hide_details' => __('Hide Details', 'space-usage-alpha'),
                'show_plugins' => __('Show Plugins Size', 'space-usage-alpha'),
                'hide_plugins' => __('Hide Plugins Size', 'space-usage-alpha'),
                'show_themes' => __('Show Themes Size', 'space-usage-alpha'),
                'hide_themes' => __('Hide Themes Size', 'space-usage-alpha'),
            ]
        ]);
    }

    /**
     * Get the version number for a file.
     *
     * @param string $file_path Relative path to the file from the plugin root.
     * @return string Version number.
     */
    private static function get_file_version($file_path) {
        $file_path = SUA_PLUGIN_PATH . $file_path;

        if (file_exists($file_path)) {
            return (string) filemtime($file_path);
        }

        return self::ASSET_VERSION; // Fallback to the constant version if the file does not exist.
    }
}
