=== Space Usage Alpha ===
Contributors: Zain Minhas
Donate link: https://example.com/donate
Tags: disk space, memory usage, database size, wp-content size, system information
Requires at least: 4.7
Tested up to: 6.3
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Monitor your disk space, memory usage, database size, and WP content folder size within the WordPress admin panel.
== Description ==
Space Usage Alpha provides an easy-to-use interface to monitor your server's disk space, memory usage, database size, and WordPress content folder size. It helps you keep track of available resources, ensuring that your website runs smoothly without running out of space or memory.
Key features:
Display total disk space, used disk space, and memory usage
Show database size with detailed table information
Provide WP content folder size, including plugins and themes
Display media library size
Refresh data with a single click
Caching for faster data retrieval
Responsive and user-friendly interface
== Installation ==
Upload the space-usage-alpha folder to the /wp-content/plugins/ directory.
Activate the plugin through the 'Plugins' menu in WordPress.
Navigate to 'Space Usage Alpha' in the admin menu to view the system information.
== Frequently Asked Questions ==
= What does this plugin do? =
This plugin displays the total disk space, used disk space, memory usage, database size, and WP content folder size of your server.
= Is it compatible with my version of WordPress? =
The plugin requires WordPress version 4.7 or higher and has been tested up to version 6.3.
= Can I customize the plugin's appearance? =
Yes, you can customize the CSS styles to match your website's design.
== Screenshots ==
Plugin's admin page showing disk space, memory usage, and database size
Detailed view of database tables and their sizes
WP content folder size, including plugins and themes
Media library size
== Changelog ==
= 1.0 =
Initial release of Space Usage Alpha