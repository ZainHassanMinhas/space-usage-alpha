jQuery(document).ready(function($) {

    function showLoading() {
        $('#sua-loading').show();
    }

    function hideLoading() {
        $('#sua-loading').hide();
    }

    function showError(message) {
        $('#sua-error').text(message).show();
    }

    function hideError() {
        $('#sua-error').hide();
    }

    // Fetch disk space and memory usage
    function fetchDiskSpaceMemoryUsage() {
        showLoading();
        hideError();
        $.ajax({
            url: sua_ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'sua_get_disk_space_memory_usage',
                security: sua_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#disk-total').text(response.data.disk_total);
                    $('#disk-used').text(response.data.disk_used);
                    $('#memory-total').text(response.data.memory_total);
                    $('#memory-used').text(response.data.memory_used);
                } else {
                    showError('Error fetching disk space and memory usage data');
                }
            },
            error: function() {
                showError('Error fetching disk space and memory usage data');
            },
            complete: hideLoading
        });
    }

    // Fetch database size
    function fetchDatabaseSize() {
        showLoading();
        hideError();
        $.ajax({
            url: sua_ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'sua_get_database_size',
                security: sua_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#database-size p').text('Total size: ' + response.data.total_size);
                    $('#database-tables').empty();
                    response.data.tables.forEach(function(table) {
                        $('#database-tables').append('<tr><td>' + table.name + '</td><td>' + table.size + '</td></tr>');
                    });
                } else {
                    showError('Error fetching database size data');
                }
            },
            error: function() {
                showError('Error fetching database size data');
            },
            complete: hideLoading
        });
    }

    // Fetch WP content size
    function fetchWPContentSize() {
        showLoading();
        hideError();
        $.ajax({
            url: sua_ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'sua_get_wp_content_size',
                security: sua_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#wp-content-size p').text('Total size: ' + response.data.total_size);
                    $('#plugins-list').empty();
                    $('#themes-list').empty();
                    response.data.plugins_list.forEach(function(plugin) {
                        $('#plugins-list').append('<tr><td>' + plugin.name + '</td><td>' + plugin.size + '</td></tr>');
                    });
                    response.data.themes_list.forEach(function(theme) {
                        $('#themes-list').append('<tr><td>' + theme.name + '</td><td>' + theme.size + '</td></tr>');
                    });
                } else {
                    showError('Error fetching WP content size data');
                }
            },
            error: function() {
                showError('Error fetching WP content size data');
            },
            complete: hideLoading
        });
    }

    // Toggle functionality for plugins and themes
    $('#toggle-plugins').on('click', function() {
        $('.plugins-table').toggle(); // Show/hide the plugins table
        $(this).text(function(i, text) {
            return $('.plugins-table').is(':visible') ? sua_ajax_object.i18n.hide_plugins : sua_ajax_object.i18n.show_plugins;
        });
    });

    $('#toggle-themes').on('click', function() {
        $('.themes-table').toggle(); // Show/hide the themes table
        $(this).text(function(i, text) {
            return $('.themes-table').is(':visible') ? sua_ajax_object.i18n.hide_themes : sua_ajax_object.i18n.show_themes;
        });
    });

    // Fetch media size
    function fetchMediaSize() {
        showLoading();
        hideError();
        $.ajax({
            url: sua_ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'sua_get_media_size',
                security: sua_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#media-size p').text('Total size: ' + response.data.media_size);
                } else {
                    showError('Error fetching media size data');
                }
            },
            error: function() {
                showError('Error fetching media size data');
            },
            complete: hideLoading
        });
    }

    // Refresh button handlers
    $('#refresh-disk-memory').on('click', fetchDiskSpaceMemoryUsage);
    $('#refresh-database').on('click', fetchDatabaseSize);
    $('#refresh-wp-content').on('click', fetchWPContentSize);
    $('#refresh-media').on('click', fetchMediaSize);

    // Toggle functionality for database details
    $('#toggle-database').on('click', function() {
        $('#database-details').toggle();
        $(this).text(function(i, text) {
            return $('#database-details').is(':visible') ? sua_ajax_object.i18n.hide_details : sua_ajax_object.i18n.show_details;
        });
    });

    // Initial data fetch
    fetchDiskSpaceMemoryUsage();
    fetchDatabaseSize();
    fetchWPContentSize();
    fetchMediaSize();

});