<div class="wrap space-usage-alpha">

    <h1><span class="dashicons dashicons-chart-area"></span> <?php esc_html_e('Space Usage Alpha', 'space-usage-alpha'); ?></h1>

    <div id="sua-loading" style="display:none;">
        <span class="spinner is-active"></span> <?php esc_html_e('Loading...', 'space-usage-alpha'); ?>
    </div>

    <div id="sua-error" class="notice notice-error" style="display:none;"></div>

    <h2><span class="dashicons dashicons-desktop"></span> <?php esc_html_e('Disk Space and Memory Usage', 'space-usage-alpha'); ?></h2>

    <table class="form-table">
        <tr>
            <th><?php esc_html_e('Total Disk Space', 'space-usage-alpha'); ?></th>
            <td id="disk-total"><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></td>
        </tr>
        <tr>
            <th><?php esc_html_e('Used Disk Space', 'space-usage-alpha'); ?></th>
            <td id="disk-used"><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></td>
        </tr>
        <tr>
            <th><?php esc_html_e('Total Memory', 'space-usage-alpha'); ?></th>
            <td id="memory-total"><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></td>
        </tr>
        <tr>
            <th><?php esc_html_e('Used Memory', 'space-usage-alpha'); ?></th>
            <td id="memory-used"><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></td>
        </tr>
    </table>

    <button id="refresh-disk-memory" class="button">
        <span class="dashicons dashicons-update"></span> 
        <?php esc_html_e('Refresh', 'space-usage-alpha'); ?>
    </button>

    <h2><span class="dashicons dashicons-database"></span> <?php esc_html_e('Database Size', 'space-usage-alpha'); ?></h2>

    <div id="database-size">
        <p><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></p>
        <button id="toggle-database" class="button"><span class="dashicons dashicons-visibility"></span> <?php esc_html_e('Show Details', 'space-usage-alpha'); ?></button>
        <button id="refresh-database" class="button">
            <span class="dashicons dashicons-update"></span> 
            <?php esc_html_e('Refresh', 'space-usage-alpha'); ?>
        </button>
        <div id="database-details" style="display:none;">
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Table Name', 'space-usage-alpha'); ?></th>
                        <th><?php esc_html_e('Size', 'space-usage-alpha'); ?></th>
                    </tr>
                </thead>
                <tbody id="database-tables">
                    <!-- Database tables will be inserted here via AJAX -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- WP Content Size -->
    <h2><span class="dashicons dashicons-admin-plugins"></span> <?php esc_html_e('WP Content Size', 'space-usage-alpha'); ?></h2>
<div id="wp-content-size">
    <p><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></p>
    <button id="toggle-plugins" class="button">
        <span class="dashicons dashicons-admin-plugins"></span>
        <?php esc_html_e('Show Plugins Size', 'space-usage-alpha'); ?>
    </button>
    <div class="plugins-table" style="display:none;"> <!-- Ensure this is hidden by default -->
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php esc_html_e('Plugin Name', 'space-usage-alpha'); ?></th>
                    <th><?php esc_html_e('Size', 'space-usage-alpha'); ?></th>
                </tr>
            </thead>
            <tbody id="plugins-list">
                <!-- Plugin sizes will be inserted here via AJAX -->
            </tbody>
        </table>
    </div>

    <button id="toggle-themes" class="button">
        <span class="dashicons dashicons-admin-appearance"></span>
        <?php esc_html_e('Show Themes Size', 'space-usage-alpha'); ?>
    </button>
    <div class="themes-table" style="display:none;"> <!-- Ensure this is hidden by default -->
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php esc_html_e('Theme Name', 'space-usage-alpha'); ?></th>
                    <th><?php esc_html_e('Size', 'space-usage-alpha'); ?></th>
                </tr>
            </thead>
            <tbody id="themes-list">
                <!-- Theme sizes will be inserted here via AJAX -->
            </tbody>
        </table>
    </div>
</div>

    <!-- Media Size -->
    <h2><span class="dashicons dashicons-admin-media"></span> <?php esc_html_e('Media Size', 'space-usage-alpha'); ?></h2>
    <div id="media-size">
        <p><?php esc_html_e('Loading...', 'space-usage-alpha'); ?></p>
        <button id="refresh-media" class="button">
            <span class="dashicons dashicons-update"></span> 
            <?php esc_html_e('Refresh', 'space-usage-alpha'); ?>
        </button>
    </div>

</div>

<style>
    .space-usage-alpha h2 {
        margin-top: 30px;
    }

    .space-usage-alpha .form-table {
        margin-bottom: 15px;
    }

    .space-usage-alpha .widefat {
        margin-top: 15px;
    }

    .space-usage-alpha .button {
        margin-right: 10px;
    }

    .space-usage-alpha .dashicons {
        vertical-align: middle;
    }
</style>